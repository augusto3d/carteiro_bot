import { OrderRepository } from './order.repository'
import { UserRepository } from './user.repository'

export { OrderRepository, UserRepository }
